// require database connection 
const dbConnect = require("./db/dbConnect");
const express = require("express");
const bodyParser = require('body-parser')
const auth = require("./services/auth")
const userRoutes = require("./routes/user.route")
const cors = require('cors')
const app = express();

// Cors Error Fix
app.use(cors())


// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json());

app.use("/", userRoutes);

// execute database connection 
dbConnect();




app.post("/", (req, res) => {
    res.send("ABHAY")
})


// free endpoint
app.get("/free-endpoint", (request, response) => {
    response.json({ message: "You are free to access me anytime" });
});

// authentication endpoint
app.get("/auth-endpoint", auth, (request, response) => {
    response.json({ message: "You are authorized to access me" });
});


app.listen(8000, () => {
    console.log("Server started on Port 8000");
})