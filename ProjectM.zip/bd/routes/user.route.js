const express = require("express");
const bcrypt = require("bcrypt");
const User = require("../models/User.model");
const jwt = require("jsonwebtoken");


const Router = express.Router();

// register endpoint
Router.post("/register", (req, res) => {
    // hash the password
    bcrypt
        .hash(req.body.password, 10)
        .then((hashedPassword) => {

            // create a new user instance and collect the data
            const user = new User({
                email: req.body.email,
                password: hashedPassword,
            });

            // save the new user
            user.save()
                // return success if the new user is added to the database successfully
                .then((result) => {
                    res.status(201).send({
                        message: "User Created Successfully",
                        result,
                    });
                })
                // catch error if the new user wasn't added successfully to the database
                .catch((error) => {
                    res.status(500).send({
                        message: "Error creating user",
                        error,
                    });
                });
        })
        // catch error if the password hash isn't successful
        .catch((e) => {
            res.status(500).send({
                message: "Password was not hashed successfully",
                e,
            });
        });
});

// login endpoint
Router.post("/login", (request, response) => {
    // check if email exists
    User.findOne({ email: request.body.email })

        // if email exists
        .then((user) => {
            // compare the password entered and the hashed password found
            bcrypt
                .compare(request.body.password, user.password)

                // if the passwords match
                .then((passwordCheck) => {

                    // check if password matches
                    if (!passwordCheck) {
                        return response.status(400).send({
                            message: "Passwords does not match",
                            error,
                        });
                    }

                    //   create JWT token
                    const token = jwt.sign(
                        {
                            userId: user._id,
                            userEmail: user.email,
                        },
                        "RANDOM-TOKEN",
                        { expiresIn: "24h" }
                    );

                    //   return success response
                    response.status(200).send({
                        message: "Login Successful",
                        email: user.email,
                        token,
                    });
                })
                // catch error if password does not match
                .catch((error) => {
                    response.status(400).send({
                        message: "Passwords does not match",
                        error,
                    });
                });
        })
        // catch error if email does not exist
        .catch((e) => {
            response.status(404).send({
                message: "Email not found",
                e,
            });
        });
});

//Health Check endpoint
Router.get("/", (req, res) => {
    res.send("Working");
})

//Register Many endpoint
Router.post("/registerAll", (req, res) => {
    // Function call 
    User.insertMany([
        ...req.body
    ]).then((result) => {
        res.status(201).send({
            message: "Users Created Successfully",
            result,
        });
    })
        // catch error if the new user wasn't added successfully to the database
        .catch((error) => {
            res.status(500).send({
                message: "Error creating users",
                error,
            });
        });
})

//Delete User Endpoint
Router.delete("/delete", (req, res) => {
    // Function call 
    User.deleteOne({ email: req.body.email })
        .then((result) => {
            res.status(201).send({
                message: "User Deleted Successfully",
                result,
            });
        })
        // catch error if the new user wasn't added successfully to the database
        .catch((error) => {
            res.status(500).send({
                message: "Error Deleting user",
                error,
            });
        });
})





module.exports = Router;

