import "./App.css";
import Header from "./components/Header";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import pages from "./pages";

function App() {
  return (
    <BrowserRouter>
      <Header />
      <Routes>
        {/* <Route path='/' element={} /> */}
        <Route path="/home" element={<pages.Home />} />
        <Route path="/login" element={<pages.Login />} />
        <Route path="/code" element={<pages.Code />} />
        <Route path="/exam" element={<pages.Exam />} />
        <Route path="/myblogs" element={<pages.MyBlogs />} />
        <Route path="/roadmaps" element={<pages.Roadmaps />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
