import React from 'react'

function Code() {
    return (
        <div>Code</div>
    )
}

export default Code