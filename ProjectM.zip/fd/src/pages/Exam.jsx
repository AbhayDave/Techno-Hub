import React from 'react'

function Exam() {
  return (
    <div>Exam</div>
  )
}

export default Exam