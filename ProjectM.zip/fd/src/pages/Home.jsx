import BlogPost from "../components/BlogPost";

function Home() {
  return (
    <>
      <BlogPost />
      <BlogPost />
      <BlogPost />
      <BlogPost />
    </>
  );
}

export default Home;
