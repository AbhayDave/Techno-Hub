import * as React from 'react';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Link from '@mui/material/Link';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import AccountCircleOutlinedIcon from '@mui/icons-material/AccountCircleOutlined';
import KeyIcon from '@mui/icons-material/Key';
import { useState } from 'react';
import LockRoundedIcon from '@mui/icons-material/LockRounded';

function Copyright(props) {
    return (
        <Typography variant="body2" color="text.secondary" align="center" {...props}>
            {'Copyright © '}
            <Link color="inherit" href="https://mui.com/">
                Techno-Hub
            </Link>{' '}
            {new Date().getFullYear()}
            {'.'}
        </Typography>
    );
}

export default function Login() {

    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')

    const handleSubmit = (event) => {
        event.preventDefault();
        // const data = new FormData(event.currentTarget);
        // console.log({
        //   email: data.get('email'),
        //   password: data.get('password'),
        // });
    };



    return (

        <Grid container component="main" sx={{ height: '100vh' }}>
            <CssBaseline />
            <Grid
                item
                xs={false}
                sm={4}
                md={7}
                sx={{
                    backgroundImage: 'url(src/assets/LoginBG.jpg)',
                    backgroundRepeat: 'no-repeat',
                    backgroundColor: (t) =>
                        t.palette.mode === 'light' ? t.palette.grey[50] : t.palette.grey[900],
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                    pointerEvents: "none",
                    userSelect: "none"
                }}
            />
            <Grid boxShadow={'none'} item xs={12} sm={8} md={5} component={Paper} elevation={6} square>
                <Box
                    sx={{
                        my: 8,
                        mx: 4,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                    }}
                >

                    <Box
                        component="img"
                        sx={{
                            height: 180,
                            width: 400,
                            maxHeight: { xs: 150, md: 190 },
                            maxWidth: { xs: 200, md: 450 },
                            mb: 2,
                            pointerEvents: "none",
                            userSelect: "none"
                        }}
                        alt="LOGO"
                        src="src\assets\Logo.png"
                    />

                    <Box component="form" noValidate onSubmit={handleSubmit} width={3 / 4} sx={{ mt: 1 }}>
                        <Box sx={{ display: 'flex', alignItems: 'flex-end' }} >
                            <AccountCircleOutlinedIcon sx={{
                                mr: 1, my: 0.5,
                                color: "#1976D2",
                                backgroundColor: "white",
                                borderRadius: "50%",
                                fontSize: 45
                            }} />
                            <TextField margin="normal"
                                required
                                fullWidth
                                id="email"
                                label="Email Address"
                                name="email"
                                autoComplete="email"
                                autoFocus
                                variant="standard"
                                value={email}
                                onChange={(e) => { setEmail(e.target.value) }}
                            />
                        </Box>

                        <Box sx={{ display: 'flex', alignItems: 'flex-end', my: 2.5 }}>
                            <LockRoundedIcon sx={{
                                mr: 1, my: 0.5,
                                color: "#1976D2",
                                backgroundColor: "white",
                                borderRadius: "50%",
                                fontSize: 45
                            }} />
                            <TextField margin="normal"
                                required
                                fullWidth
                                name="password"
                                label="Password"
                                type="password"
                                id="password"
                                autoComplete="current-password"
                                variant="standard"
                                value={password}
                                onChange={(e) => { setPassword(e.target.value) }}
                            />
                        </Box>


                        <FormControlLabel
                            control={<Checkbox value="remember" color="primary" />}
                            label="Remember me"
                        />
                        <br />

                        <Box
                            m={1}
                            display="flex"
                            justifyContent="center"
                            alignItems="center"
                        >
                            <Button type="submit"
                                variant="contained"
                                sx={{ mt: 2, mb: 1.5, p: 1.5, pr: 3, pl: 3 }} size='large' endIcon={<KeyIcon />}>
                                Login
                            </Button>
                        </Box>

                        <Grid container>
                            <Link href="#" variant="body2">
                                Forgot password?
                            </Link>
                        </Grid>
                        <Copyright sx={{ mt: 5 }} />
                    </Box>
                </Box>
            </Grid>
        </Grid>
    );
}