import { Box, Container, Button } from "@mui/material";
import AsynchronousSearch from "../components/AsynchronousSearch";
import AddIcon from "@mui/icons-material/Add";
function MyBlogs() {
  return (
    <Container
      sx={{
        // border: "1px solid red",
        margin: "0 auto",
        marginTop: 10,
        display: "flex",
        justifyContent: "space-around",
        alignItems: "center",
      }}
    >
      <AsynchronousSearch />

      <Box>
        <Button component="label" variant="contained" startIcon={<AddIcon />}>
          Create New Blog
        </Button>
      </Box>
    </Container>
  );
}

export default MyBlogs;
