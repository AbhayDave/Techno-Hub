import Code from "./Code"
import Exam from "./Exam"
import Home from "./Home"
import Login from "./Login"
import MyBlogs from "./MyBlogs"
import Roadmaps from "./Roadmaps"


export default { Code, Exam, Home, Login, MyBlogs, Roadmaps}